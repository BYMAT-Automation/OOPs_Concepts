package encapsulation_B11;

public class TestEncpsulationClass {
	
	public static void main(String[] args) {
		
		Bank_Account_B11 ba = new Bank_Account_B11();
		
		ba.setAccount_no(123456789);
		ba.setAccount_holder_name("Rahul");
		ba.setAccnt_balance(-14564645);
		ba.setAccount_holder_contact_no(1234545689);
		
		System.out.println(ba.getAccount_no() +" is having balance "+ba.getAccnt_balance() +" for account holder "+ba.getAccount_holder_name()
														+" and his contact number is "+ba.getAccount_holder_contact_no());	
	}

}
