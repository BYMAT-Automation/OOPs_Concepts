package encapsulation_B11;

public class Bank_Account_B11 {
	
	private int account_no;
	private double accnt_balance = 10;
	private String account_holder_name;
	private long account_holder_contact_no;
	
	//this keyword is responsible to create a object of the class
	
	public int getAccount_no() {
		return account_no;
	}
	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}
	public double getAccnt_balance() {
		return accnt_balance;
	}
	public void setAccnt_balance(double accnt_balance) {
		if(accnt_balance <0)
		System.out.println("Please enter the valid amount");
		else
		this.accnt_balance = this.accnt_balance+accnt_balance;
	}
	public String getAccount_holder_name() {
		return account_holder_name;
	}
	public void setAccount_holder_name(String account_holder_name) {
		this.account_holder_name = account_holder_name;
	}
	public long getAccount_holder_contact_no() {
		return account_holder_contact_no;
	}
	public void setAccount_holder_contact_no(long account_holder_contact_no) {
		this.account_holder_contact_no = account_holder_contact_no;
	}

}
