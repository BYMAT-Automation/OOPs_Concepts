package inheritance;

public class Class_A extends Class_B {
	
	
	public static void main(String[] args) {
		
		System.out.println("Training Name is :-" +training);
		System.out.println("Second variable is :-" +a);
		
		addition();
	}
	
	
	

}
