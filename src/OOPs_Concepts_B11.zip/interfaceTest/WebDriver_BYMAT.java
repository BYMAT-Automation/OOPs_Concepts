package interfaceTest;

public interface WebDriver_BYMAT {
	
	public void getTitle();
	
	public void getURL();
	
	public void close();
	
	public void quit();
	
	public void click();
	
	public void clear();
	
	public void getText();
	
	public void screenShot();
	
	public void xyzMathod();
	
}
