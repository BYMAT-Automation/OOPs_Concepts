package polymorphism;

public class HDFC_Bank extends RBI_Bank {
	
	public double getRateOfInterest() {
		
		System.out.println("I am in HDFC bank");
		
		return 9.1;
	}


}
