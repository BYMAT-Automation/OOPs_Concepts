package polymorphism;

public class RBI_Bank {
	
	public double getRateOfInterest() {
		
		System.out.println("I am in RBI bank");
		
		return 7.5;
	}

}
