package polymorphism;

public class ICICI_Bank extends RBI_Bank {
	
	public double getRateOfInterest() {
		
		System.out.println("I am in ICICI bank");
		
		return 8.7;
	}


}
