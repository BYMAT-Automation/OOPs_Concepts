package abstraction;

public class ICICI_Bank extends RBI_Bank {
	
	public int getRateOfInterest() {
		
		System.out.println("I am in ICICI bank class");
		
		return 8;
	}

}
