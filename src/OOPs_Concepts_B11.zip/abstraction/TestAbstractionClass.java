package abstraction;

public class TestAbstractionClass {
	
	public static void main(String[] args) {
		
		RBI_Bank b;
		
		 b = new ICICI_Bank();
		
		System.out.println( b.getRateOfInterest()+" %");
		
		b.getAccountDetails();
		
	     b = new HDFC_Bank();
		
		System.out.println( b.getRateOfInterest()+" %");
		b.getAccountDetails();
	}

}
