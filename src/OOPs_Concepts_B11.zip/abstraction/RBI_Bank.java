package abstraction;

public abstract class RBI_Bank {
	
	public abstract int getRateOfInterest(); // signature of the method // Interface
	
	public static void getAccountDetails() {
		
		System.out.println("I am in non abstract method of Abstract classs");
	}

}
