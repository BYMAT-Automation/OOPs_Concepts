package interfaceTest;

public class ChromeDriver_BYMAT implements WebDriver_BYMAT{

	@Override
	public  void getTitle() {
		System.out.println("Code to get the page title from Chrome browser");
		
	}

	@Override
	public void getURL() {
		System.out.println("Code to navigate to URL from Chrome browser");
		
	}

	@Override
	public void close() {
		System.out.println("Code to close the active of Chrome browser");
		
	}

	@Override
	public void quit() {
		System.out.println("Code to kill the Chrome browser");
		
	}

	@Override
	public void click() {
		System.out.println("Code to click on button in Chrome browser");
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getText() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void screenShot() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void xyzMathod() {
		// TODO Auto-generated method stub
		
	}

}
