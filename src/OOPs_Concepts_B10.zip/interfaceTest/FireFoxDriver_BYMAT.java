package interfaceTest;

public class FireFoxDriver_BYMAT implements WebDriver_BYMAT{

	@Override
	public void getTitle() {
		System.out.println("Code to get the page title from FireFox browser");
		
	}

	@Override
	public void getURL() {
		System.out.println("Code to navigate to URL from FireFox browser");
		
	}

	@Override
	public void close() {
		System.out.println("Code to close the active of FireFox browser");
		
	}

	@Override
	public void quit() {
		System.out.println("Code to kill the FireFox browser");
		
	}

	@Override
	public void click() {
		System.out.println("Code to click on button in FireFox browser");
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getText() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void screenShot() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void xyzMathod() {
		// TODO Auto-generated method stub
		
	}

}
