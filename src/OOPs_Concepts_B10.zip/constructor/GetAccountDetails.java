package constructor;

public class GetAccountDetails {

	public int Account_no= 0;

	public GetAccountDetails() { // Default Constructor
		System.out.println("I am in a default Constructor");
		
	}

	public GetAccountDetails(int Account_no) { // Argumented Constructor
		System.out.println("I am in a argumented Constructor");
	//	Account_no = Account_no;
	
		this.Account_no = Account_no;		
	}
	// Sql query to get the account details for the Account_No passed by customer
	
	public double getAccountBalance() {
		System.out.println("Code to get getAccountBalance for Account_no:- " + Account_no);
		
		// Sql query to get the account details for the Account_No passed by customer	
		 
		double balace = 8484.24; // select * from xyzTable where schemaName.Account_no = Account_no;
		
		return balace;
	}

	
	public String getAccountOwner() {
		System.out.println("Code to get getAccountOwner name for Account_no:- " + Account_no);
		// Sql query to get the account details for the getAccountOwner
		
		return "XYZ";
	}
	
	
	public String getAccountOwnerAddress() {
		System.out.println("Code to get getAccountOwnerAddress for Account_no:- " + Account_no);
		
		// Sql query to get the account details for the Account_No passed by customer
		return "XYZ";
	}
	
	
	public String getAccountDeatils() {
		System.out.println("Code to get getAccountBalance for Account_no:- " + Account_no);
		System.out.println("Code to get getAccountOwner name for Account_no:- " + Account_no);
		System.out.println("Code to get getAccountOwnerAddress for Account_no:- " + Account_no);
		
		// Sql query to get the account details for the Account_No passed by customer
		return "XYZ";
	}
		
	
}
