package constructor;

public class TestConstructor {
	
	public static void main(String[] args) {
		
		//GetAccountDetails gad;
		
		 //gad = new GetAccountDetails(); //  
		
		 GetAccountDetails gad = new GetAccountDetails(12345); //  
		
		 gad.getAccountBalance();
		 
		 gad.getAccountOwner();
		 
		 gad.getAccountOwnerAddress();
		
	}

}
