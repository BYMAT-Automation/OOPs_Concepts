package inheritance;

public class newClass {

	public static void main(String[] args) {
		
		Class_B b = new Class_B();
		
		int c = b.a;
		
		b.addition();

	}

}
