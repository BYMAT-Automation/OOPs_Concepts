package abstraction;

public abstract class RBI_Bank {
	
	
	public abstract double getRateOfInterest(); // Signature of method // interface as well 
	
	public static void insuranceType() {
		System.out.println("I am in non Abstract method");
		System.out.println("I am in a Static method");
	}

}
